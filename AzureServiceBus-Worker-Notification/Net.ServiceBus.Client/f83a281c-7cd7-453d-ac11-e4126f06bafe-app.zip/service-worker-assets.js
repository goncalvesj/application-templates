﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-xbodEx8SfFjQwcIT9kTWPiIKFbpZEXVvF1mQEx0KlPU=",
      "url": "_framework\/blazor.webassembly.js"
    },
    {
      "hash": "sha256-Azk5sbYFVo84h8NpIst9roIPGLH2y8ewQ9SY\/sUHvgs=",
      "url": "_framework\/dotnet.6.0.9.cr8701loy2.js"
    },
    {
      "hash": "sha256-DCornv7RwGmh5F2M7NdY9Sg66xjw779ggSN9nS\/Br5o=",
      "url": "_framework\/dotnet.timezones.blat"
    },
    {
      "hash": "sha256-CRSVnpjT1ALt26HB3lpmfQTd8vkIZUsIJDBHucyzQ7Y=",
      "url": "_framework\/dotnet.wasm"
    },
    {
      "hash": "sha256-WPyI4hWDPnOw62Nr27FkzGjdbucZnQD+Ph+GOPhAedw=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-4RwaPx87Z4dvn77ie\/ro3\/QzyS+\/gGmO3Y\/0CSAXw4k=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-OxylFgLJlFqixsj+nLxYVsv5iZLvfIKMpLf9hrWaChA=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-Zuq0dWAsBm6\/2lSOsz7+H9PvFaRn61KIXHMMwXDfvyE=",
      "url": "_framework\/icudt.dat"
    },
    {
      "hash": "sha256-ALxQRtj4JNoOUvQV3UXg+e2pw05BG51mDH3hg4hnr4M=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-\/EZ2Wjk\/SILOdGLc1hRqok\/zqj7fZ73vvYDjjO2C4wU=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-eJD83FRQvz4SIIRROxybH24yTv0YbDVo4VEwFqd8Wr8=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-x250JKThZfGMDpAIM4Wysh8J7krn7XT0m0TA7D6RfvQ=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-k2qqpMLSqFvWFMxhW5n8OlGLowGOttbCdSsNgWO\/Jeo=",
      "url": "_framework\/Microsoft.AspNetCore.Connections.Abstractions.dll"
    },
    {
      "hash": "sha256-w+EAv300i5ZG3TV+dXZputtF82HWeKUm9B\/L9jsH\/X0=",
      "url": "_framework\/Microsoft.AspNetCore.Http.Connections.Client.dll"
    },
    {
      "hash": "sha256-uUrabo2xpp6tr1eRgAI4GG3ybCIWgehpg6R69cfoynk=",
      "url": "_framework\/Microsoft.AspNetCore.Http.Connections.Common.dll"
    },
    {
      "hash": "sha256-KRo8pfrc\/VE8xvUAfFere3IYVYNKgZZkSOVguSJrQiM=",
      "url": "_framework\/Microsoft.AspNetCore.SignalR.Client.Core.dll"
    },
    {
      "hash": "sha256-OfsK7vD6k+EhMxudRALmoKsyKBSaDwQDbUft12XM3+M=",
      "url": "_framework\/Microsoft.AspNetCore.SignalR.Client.dll"
    },
    {
      "hash": "sha256-Er\/9a39lrEEyA\/IOX7jXWWKajqBYysLTGxn+gjm+E\/0=",
      "url": "_framework\/Microsoft.AspNetCore.SignalR.Common.dll"
    },
    {
      "hash": "sha256-BAeMUV8uO8bbni2uKMSFNPTDu5h6UmlEM1Mp4uepSKk=",
      "url": "_framework\/Microsoft.AspNetCore.SignalR.Protocols.Json.dll"
    },
    {
      "hash": "sha256-yNUivmV4a48Mkbc1Sz+XJ9Y8moJKjWJo6Z0haFMFrKQ=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-OWH+xkIa4nRWGQutqm7dxgAY22jFGJlC+P6RzpDPrBE=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-boSewHLerYdMMQk1EahIMSbAXSrf7Kgky4CGjZ3uuto=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-Zv1VxyxzhN12fzYNYzTS\/FMV1mVnLKt1YZZOiks0mOc=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-Tp5zDFaHR2NBQU9zm0ePgm4q84IJasATdQNv6me1LtE=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-buwzkNdED9P0MXQpETvuhfILcchUhpy3upET3EzAXbQ=",
      "url": "_framework\/Microsoft.Extensions.Features.dll"
    },
    {
      "hash": "sha256-KlotVQQ+AdhQaqulvgW7uaw\/s3mqHuHcqGxVg4CEa9I=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-fBW3KrJJlHtIjYR6\/BJT82+enResUQBbfk9Vi+1B08Y=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-P0D4G8tvHyfwKnITI89S8K1YF1poldYCmd\/W1m4E7IU=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-Kk9trPYi6xuop+bJh7AertZVcNJkEyzyxW3andlyf5U=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-0CQPLSq1yKZV\/js+sBdrwV86Gpcky32r+w\/L0IXWRqo=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-ZvHWrxEeEN5h9m1gPb4wOyKkjA8F4fUhyUaYoFYr7IU=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-AuLk3Tm7H\/yWKHVUKcdYbcPT8TEaqiC1mASbTZavXRk=",
      "url": "_framework\/Microsoft.Win32.Primitives.dll"
    },
    {
      "hash": "sha256-zvPj60aLGCopi5ykygFgUgWYsEfXt+11u\/rgPUWNlNc=",
      "url": "_framework\/Net.ServiceBus.Client.dll"
    },
    {
      "hash": "sha256-lTREAjBdiazO+VlnMMgUbu1+9rgnZveKNWds87tDLBg=",
      "url": "_framework\/System.Collections.Concurrent.dll"
    },
    {
      "hash": "sha256-1bQHn09FDmzElESq4cqqxDDJ2a7nkXG55ZpWJKIta60=",
      "url": "_framework\/System.Collections.dll"
    },
    {
      "hash": "sha256-MXglLK7p6+kGHwmiWeJCcSE9GTbOJwnuZnT\/TTJJ+\/g=",
      "url": "_framework\/System.Collections.NonGeneric.dll"
    },
    {
      "hash": "sha256-FwvUyO1L86X6SFYYN75RKhxCVBkNrBdiZCjvwM4zOS0=",
      "url": "_framework\/System.ComponentModel.dll"
    },
    {
      "hash": "sha256-ZqDSDeH28UuCcbUimzRq28B9mvpo+QHi0QuXuk\/E5Ts=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-papiUPKV8b1XuKsrtRwY5QCpEpW1p67is4JOQm95mAQ=",
      "url": "_framework\/System.Linq.dll"
    },
    {
      "hash": "sha256-\/iI65Yv1Pga8h8YsFJDN79yrbGB4vXX14eaFIU7t9CA=",
      "url": "_framework\/System.Linq.Expressions.dll"
    },
    {
      "hash": "sha256-M0K6tlAXGKMgGpvke45k8PTKwYLPAIFgq13\/iqVIBrw=",
      "url": "_framework\/System.Memory.dll"
    },
    {
      "hash": "sha256-8dJByyyMCsYsDf0pKM++T1+SPqavcGV\/iCLdc1UVpvE=",
      "url": "_framework\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-v+\/1xq480SQq+ddYC\/oUQ9GihRfaCx7ocp2IPWr6QP8=",
      "url": "_framework\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-L\/9DwMDoMHjK30\/cMNespF4+K\/Lvu20zQ2oksYG2jqQ=",
      "url": "_framework\/System.Net.Primitives.dll"
    },
    {
      "hash": "sha256-pK20X+koFfsf0vq9kLKlN0HC3pUNkO2ciIBWo9NXNkA=",
      "url": "_framework\/System.Net.Requests.dll"
    },
    {
      "hash": "sha256-sUmm1upejgL3freszGeCE7tQsn7D9ew0PgNREoi+qVI=",
      "url": "_framework\/System.Net.Security.dll"
    },
    {
      "hash": "sha256-22gCoRdVnByBIVcdLcS18YL3jYRYffaEIeL5JZTsRR8=",
      "url": "_framework\/System.Net.Sockets.dll"
    },
    {
      "hash": "sha256-Qikh755PPPBq+F88D0y4gwf+viQ2fCvXz0AlRyqf0Hs=",
      "url": "_framework\/System.Net.WebSockets.Client.dll"
    },
    {
      "hash": "sha256-XTKo0wIYfwSFL4p4x+9xbXGWw0YCbqQVYayzvuOc5sc=",
      "url": "_framework\/System.Net.WebSockets.dll"
    },
    {
      "hash": "sha256-AjONxAQXK\/8idsXEF+riCd8Phr\/cGC8cE0PZU6kBQ+8=",
      "url": "_framework\/System.ObjectModel.dll"
    },
    {
      "hash": "sha256-H2zQGzu8ePRzI0zJyEqSzk2VKkuabAfj0SoA1h4D0sc=",
      "url": "_framework\/System.Private.CoreLib.dll"
    },
    {
      "hash": "sha256-VZqG6FHD1EMQRir404RXnpCzXOj\/9jmAKiAFBM3xtjI=",
      "url": "_framework\/System.Private.Runtime.InteropServices.JavaScript.dll"
    },
    {
      "hash": "sha256-KBvn0dCNv+9qfcmLKi+PpqkPUk\/9lPcydVN7+6YoTXs=",
      "url": "_framework\/System.Private.Uri.dll"
    },
    {
      "hash": "sha256-OPSo5EHU0reQeIKLhLAz3x9kgcCl1hJ+AmJZOzwMLZ0=",
      "url": "_framework\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-5\/yX4jWAm8QtqVzrEBCaE8rOyYtfKx63Y6gNdutnFBU=",
      "url": "_framework\/System.Runtime.dll"
    },
    {
      "hash": "sha256-3Wcy32D4K3YFhyiExAtjaN71DEfpcwt9guFZ27i0b9I=",
      "url": "_framework\/System.Runtime.InteropServices.RuntimeInformation.dll"
    },
    {
      "hash": "sha256-Az9fpIcuZ01ggGRnjZRorquCKUxTfKJDNbpNQML7J6Q=",
      "url": "_framework\/System.Security.Claims.dll"
    },
    {
      "hash": "sha256-0cwQ4Uq0uJuGAY4GM+2M4IqMBxzf1VsdgejTuudxqsc=",
      "url": "_framework\/System.Security.Cryptography.X509Certificates.dll"
    },
    {
      "hash": "sha256-9+kjzn39K7Cs2u4bIzu23JJsrjROTmFcetfX6Wzz2wA=",
      "url": "_framework\/System.Text.Encoding.Extensions.dll"
    },
    {
      "hash": "sha256-eegpn1YUyCHTtZcgbKj326SKssHN7S8H1qGN7YViN1U=",
      "url": "_framework\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-caueAf\/UiUeDmB68SwUb2XFq2kkQAiAuF3MAYZsQ3NA=",
      "url": "_framework\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-sqneUAZo\/Rk1aLqO9WWGjcEVPH1L052cbvHWJExyFKQ=",
      "url": "_framework\/System.Threading.Channels.dll"
    },
    {
      "hash": "sha256-4KY2ASibMEviQ30cazenb+peIq2Cyxcw75hMOzXorwI=",
      "url": "_framework\/System.Threading.dll"
    },
    {
      "hash": "sha256-FD+iR7z2flBL2TLIqHD4NO+eGAGcyTlUTJ2wCCKg5so=",
      "url": "_framework\/System.Threading.ThreadPool.dll"
    },
    {
      "hash": "sha256-Bi1LRtmCq\/et1w+WoS7VdaZYrZ4JbhkRT1sfXODwmnw=",
      "url": "Net.ServiceBus.Client.styles.css"
    },
    {
      "hash": "sha256-lDAEEaul32OkTANWkZgjgs4sFCsMdLsR5NJxrjVcXdo=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk\/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-YTA5qKssTpbkLoBFUhNzpH1FMtVRLmwO+v+m5MvIuuo=",
      "url": "index.html"
    },
    {
      "hash": "sha256-znTv6SOO7o22FX9qF5QGBiaYRUAp5pDNvhcsz8kMrp0=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yzFf+O\/mlH+Q9klUSqXP2kxGKOUFLPxaww8da8fKhGU=",
      "url": "sample-data\/weather.json"
    }
  ],
  "version": "g7u090+f"
};
